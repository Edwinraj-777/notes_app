// lib/screens/browse_page.dart
import 'package:flutter/material.dart';

class BrowsePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Browse Page'));
  }
}
