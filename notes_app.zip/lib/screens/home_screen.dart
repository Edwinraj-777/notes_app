import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/note_provider.dart';
import '../widgets/custom_search_bar.dart';
import 'recents_page.dart';
import 'shared_page.dart';
import 'browse_page.dart';
import 'create_note_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  List<Widget> _pages = [
    RecentsPage(),
    SharedPage(),
    BrowsePage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _navigateToCreateNote() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CreateNoteScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notes App'),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(kToolbarHeight),
          child: CustomSearchBar(),
        ),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'Recents'),
          BottomNavigationBarItem(icon: Icon(Icons.share), label: 'Shared'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Browse'),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToCreateNote,
        child: Icon(Icons.add),
        backgroundColor: Theme.of(context).primaryColorLight,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}
