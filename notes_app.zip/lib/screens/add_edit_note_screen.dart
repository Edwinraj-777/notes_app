import 'package:flutter/material.dart';

class AddEditNoteScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add/Edit Note'),
      ),
      body: Center(
        child: Text('This is where you add or edit notes.'),
      ),
    );
  }
}
