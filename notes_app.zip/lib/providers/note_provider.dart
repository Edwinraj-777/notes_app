import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/note.dart';
import 'dart:convert';

class NoteProvider with ChangeNotifier {
  List<Note> _notes = [];

  List<Note> get notes => _notes;

  void addNote(Note note) {
    _notes.add(note);
    saveNotes();
    notifyListeners();
  }

  void updateNote(Note oldNote, Note newNote) {
    final index = _notes.indexOf(oldNote);
    if (index != -1) {
      _notes[index] = newNote;
      saveNotes();
      notifyListeners();
    }
  }

  Future<void> loadNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final notesData = prefs.getStringList('notes') ?? [];
    _notes = notesData
        .map((note) =>
            Note.fromJson(Map<String, dynamic>.from(jsonDecode(note))))
        .toList();
    notifyListeners();
  }

  Future<void> saveNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final notesData = _notes.map((note) => jsonEncode(note.toJson())).toList();
    prefs.setStringList('notes', notesData);
  }
}
